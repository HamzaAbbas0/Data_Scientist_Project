from django.db import models
from ..Conversation.models import Conversation

class DatasetandInput(models.Model):
    id = models.AutoField(primary_key=True)
    file = models.FileField(upload_to='datasets/')
    target_variable = models.CharField(max_length=100, null=True)
    datetime_column = models.CharField(max_length=100, blank=True, null=True)
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='data_and_input')
    problem_type = models.CharField(max_length=100, null=True)


    def __str__(self):
        return f"DatasetandInput {self.id}"